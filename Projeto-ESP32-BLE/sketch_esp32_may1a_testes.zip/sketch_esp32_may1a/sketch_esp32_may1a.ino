#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHTesp.h"
#include <Adafruit_INA219.h>

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#include "BluetoothSerial.h"
#include "esp_task_wdt.h"
#include "esp_system.h"
#include "Preferences.h"

// ================= CONFIG =================
#define DEBUG true
#define WDT_TIMEOUT 10

#define DHT_PIN 19
#define LED_BLE 17
#define LED_BT  18

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDRESS 0x3C

#define BLE_DEVICE_NAME "ESP32_MONITOR_BLE"

// ================= LOG =================
#define LOG(x) if (DEBUG) Serial.println(x)

// ================= OBJETOS =================
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
DHTesp dhtSensor;
Adafruit_INA219 ina219;
BluetoothSerial SerialBT;

BLEServer* pServer = nullptr;
BLECharacteristic* pCharacteristic = nullptr;

Preferences prefs;

// ================= ESTADO =================
bool bleConnected = false;
bool btConnected = false;

float temp = -9999;
float hum = -9999;
float busVoltage = -9999;
float current_mA = -9999;
float power_mW = -9999;

unsigned long lastSend = 0;

// ================= UTIL =================
String safeFloat(float v, int dec = 1) {
  if (v == -9999) return "-9999";
  return String(v, dec);
}

// ================= RESET REASON =================
String getResetReason() {
  esp_reset_reason_t reason = esp_reset_reason();

  switch (reason) {
    case ESP_RST_POWERON: return "POWERON";
    case ESP_RST_EXT: return "EXTERNAL";
    case ESP_RST_SW: return "SOFTWARE";
    case ESP_RST_PANIC: return "PANIC";
    case ESP_RST_INT_WDT: return "INT_WDT";
    case ESP_RST_TASK_WDT: return "TASK_WDT";
    case ESP_RST_WDT: return "WDT";
    default: return "UNKNOWN";
  }
}

// ================= CHECKPOINT =================
void saveCheckpoint(String point) {
  prefs.putString("last_point", point);
}

String getLastCheckpoint() {
  return prefs.getString("last_point", "NONE");
}

// ================= BLE CALLBACK =================
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    bleConnected = true;
    LOG("BLE CONNECTED");
  }

  void onDisconnect(BLEServer* pServer) {
    bleConnected = false;
    LOG("BLE DISCONNECTED");
    BLEDevice::startAdvertising();
  }
};

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(2000);

  prefs.begin("debug", false);

  LOG("=== BOOT ===");

  LOG("RESET REASON: " + getResetReason());
  LOG("LAST CHECKPOINT: " + getLastCheckpoint());

  // Watchdog (core 3.x)
  esp_task_wdt_config_t wdt_config = {
    .timeout_ms = WDT_TIMEOUT * 1000,
    .idle_core_mask = 1,
    .trigger_panic = true
  };
  esp_task_wdt_init(&wdt_config);
  esp_task_wdt_add(NULL);

  pinMode(LED_BLE, OUTPUT);
  pinMode(LED_BT, OUTPUT);

  Wire.begin(21, 22);
  Wire.setTimeOut(50);
  LOG("I2C OK");

  dhtSensor.setup(DHT_PIN, DHTesp::DHT22);
  LOG("DHT INIT OK");

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    LOG("OLED FAIL");
  } else {
    LOG("OLED OK");
  }

  if (!ina219.begin()) {
    LOG("INA219 FAIL");
  } else {
    LOG("INA219 OK");
  }

  SerialBT.begin("ESP32_MONITOR_BT");
  LOG("BT CLASSIC READY");

  BLEDevice::init(BLE_DEVICE_NAME);

  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService* pService = pServer->createService("12345678-1234-1234-1234-1234567890ab");

  pCharacteristic = pService->createCharacteristic(
    "abcd1234-1234-1234-1234-abcdef123456",
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );

  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();

  BLEDevice::startAdvertising();
  LOG("BLE READY");

  LOG("=== SETUP DONE ===");
}

// ================= LOOP =================
void loop() {
  saveCheckpoint("LOOP_START");

  esp_task_wdt_reset();

  if (millis() - lastSend >= 1000) {
    lastSend = millis();

    saveCheckpoint("BEFORE_SENSOR");
    lerSensores();

    saveCheckpoint("AFTER_SENSOR");
    monitorarBluetooth();

    saveCheckpoint("AFTER_BT");
    enviarDados();

    saveCheckpoint("AFTER_SEND");
    atualizarDisplay();
  }
}

// ================= LEITURA SEGURA =================
void lerSensores() {

  saveCheckpoint("DHT_READ");

  TempAndHumidity data = dhtSensor.getTempAndHumidity();

  if (isnan(data.temperature) || isnan(data.humidity)) {
    temp = -9999;
    hum  = -9999;
    LOG("DHT ERROR");
  } else {
    temp = data.temperature;
    hum  = data.humidity;
  }

  saveCheckpoint("INA_READ");

  float v = ina219.getBusVoltage_V();
  float c = ina219.getCurrent_mA();
  float p = ina219.getPower_mW();

  if (isnan(v) || isnan(c) || isnan(p) || (v == 0 && c == 0)) {
    busVoltage = -9999;
    current_mA = -9999;
    power_mW   = -9999;
    LOG("INA219 ERROR");
  } else {
    busVoltage = v;
    current_mA = c;
    power_mW   = p;
  }
}

// ================= BLUETOOTH =================
void monitorarBluetooth() {
  static bool prev = false;

  btConnected = SerialBT.hasClient();

  if (btConnected && !prev) LOG("BT CONNECTED");
  if (!btConnected && prev) LOG("BT DISCONNECTED");

  prev = btConnected;

  digitalWrite(LED_BT, btConnected);
  digitalWrite(LED_BLE, bleConnected);
}

// ================= ENVIO =================
void enviarDados() {

  String json = "{";
  json += "\"temp\":" + safeFloat(temp,1) + ",";
  json += "\"hum\":" + safeFloat(hum,0) + ",";
  json += "\"voltage\":" + safeFloat(busVoltage,2) + ",";
  json += "\"current\":" + safeFloat(current_mA,1) + ",";
  json += "\"power\":" + safeFloat(power_mW,1);
  json += "}";

  LOG(json);

  if (btConnected) {
    SerialBT.println(json);
  }

  if (bleConnected) {
    pCharacteristic->setValue(json.c_str());
    pCharacteristic->notify();
  }
}

// ================= DISPLAY =================
void atualizarDisplay() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(0, 0);
  display.print("T:");
  display.print(temp);

  display.setCursor(0, 10);
  display.print("H:");
  display.print(hum);

  display.setCursor(0, 20);
  display.print("V:");
  display.print(busVoltage);

  display.setCursor(0, 30);
  display.print("I:");
  display.print(current_mA);

  display.display();
}